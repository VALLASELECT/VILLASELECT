# Villaselect 🏡

Site de location de villas et appartements.

## 🚀 Déploiement sur Vercel

### Méthode 1 – Glisser-déposer (la plus simple)

1. Allez sur [vercel.com](https://vercel.com) et créez un compte gratuit
2. Cliquez sur **"Add New Project"**
3. Choisissez **"Deploy from your computer"** ou glissez-déposez le dossier `villaselect`
4. Vercel détecte automatiquement React → cliquez **Deploy**
5. Votre site est en ligne en ~2 minutes ! 🎉

### Méthode 2 – Via GitHub (recommandée pour les mises à jour)

1. Créez un compte sur [github.com](https://github.com)
2. Créez un nouveau dépôt appelé `villaselect`
3. Uploadez tous les fichiers de ce dossier
4. Sur Vercel, connectez votre compte GitHub et importez le dépôt
5. Chaque modification sur GitHub met à jour le site automatiquement

## 🔑 Comptes de démonstration

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| Administrateur | admin@villaselect.com | admin123 |
| Utilisateur | user@demo.com | demo123 |

## ✨ Fonctionnalités

- 🏡 Catalogue de villas avec filtres
- 📅 Réservation avec minimum 7 nuits
- 💳 Acompte 50% calculé automatiquement
- 🛡️ Tableau de bord administrateur complet
- ⭐ Système d'avis clients
- 📱 Design responsive mobile

## 💳 Coordonnées bancaires configurées

- **Titulaire :** JUSTINE DELPLANQUE
- **IBAN :** FR76 1723 8000 0100 3643 2032 560
- **BIC :** SCSYFRP2
